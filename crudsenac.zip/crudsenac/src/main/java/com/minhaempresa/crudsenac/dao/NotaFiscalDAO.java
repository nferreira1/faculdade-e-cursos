/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.minhaempresa.crudsenac.dao;

import com.minhaempresa.crudsenac.models.NotaFiscal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ftfer
 */
public class NotaFiscalDAO {

    static String URL = "jdbc:mysql://localhost:3307/basenotafiscal";
    static String USER = "root";
    static String PASSWORD = "P@$$w0rd";

    public static boolean salvar(NotaFiscal obj) {

        Connection conexao = null;
        PreparedStatement comandoSQL = null;
        ResultSet rs = null;

        try {
            // 1 - Identificar o Drive
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2 - Abrir a conexão
            conexao = DriverManager.getConnection(URL, USER, PASSWORD);

            // 3 - Preparar o comando SQL
            comandoSQL = conexao.prepareStatement("INSERT INTO NotaFiscal (numeroNota, valorNota) VALUES (?, ?)",
                    PreparedStatement.RETURN_GENERATED_KEYS
            );

            comandoSQL.setInt(1, obj.getNumeroNota());
            comandoSQL.setDouble(2, obj.getValorNota());

            // 4 - Executar o comando SQL
            int linhasAfetadas = comandoSQL.executeUpdate();

            if (linhasAfetadas > 0) {

                rs = comandoSQL.getGeneratedKeys();

                if (rs != null) {
                    while (rs.next()) {
                        int id = rs.getInt(1);
                        // Atribuo o valor gerado ao objeto
                        obj.setIdNota(id);
                    }
                }
                return true;
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(NotaFiscalDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(NotaFiscalDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (conexao != null) {
                try {
                    conexao.close();
                } catch (SQLException ex) {
                    Logger.getLogger(NotaFiscalDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        return false;
    }

    public static ArrayList<NotaFiscal> listar() {

        Connection conexao = null;
        PreparedStatement comandoSQL = null;
        ResultSet rs = null;
        ArrayList<NotaFiscal> lista = new ArrayList();

        try {

            // 1 - Identificar o Drive
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2 - Abrir a conexão
            conexao = DriverManager.getConnection(URL, USER, PASSWORD);

            // 3 - Preparar o comando SQL
            comandoSQL = conexao.prepareStatement("SELECT * FROM NotaFiscal");

            // 4 - Executar o comando SQL
            rs = comandoSQL.executeQuery();

            if (rs != null) {

                // next() serve para ler linha por linha
                while (rs.next()) {
                    int id = rs.getInt("idNota");
                    int numeroNota = rs.getInt("numeroNota");
                    double valorNota = rs.getDouble("valorNota");

                    NotaFiscal item = new NotaFiscal(id, numeroNota, valorNota);

                    lista.add(item);
                }
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(NotaFiscalDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(NotaFiscalDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (conexao != null) {
                try {
                    conexao.close();
                } catch (SQLException ex) {
                    Logger.getLogger(NotaFiscalDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        return lista;
    }
}
