package negocio;
/* Teste de Classe Aluno NATHAN HENRIQUE VIEIRA FERREIRA */
public class ClasseTeste {

}
