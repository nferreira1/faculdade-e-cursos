/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.minhaempresa.crudsenac;

import com.minhaempresa.crudsenac.views.ViewConsultaNotas;

/**
 *
 * @author ftfer
 */
public class Crudsenac {

    public static void main(String[] args) {
        ViewConsultaNotas janelaPrincipal = new ViewConsultaNotas();
        janelaPrincipal.setVisible(true);
    }
}
